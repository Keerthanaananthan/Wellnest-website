import { useEffect } from 'react';
import { useApp } from '../context/AppContext';

export const useTheme = () => {
  const { settings } = useApp();

  useEffect(() => {
    const root = document.documentElement;
    
    // Remove all theme classes
    root.classList.remove('theme-light', 'theme-paleBlue', 'theme-pastel');
    
    // Add the current theme class
    root.classList.add(`theme-${settings.theme}`);
    
    // Apply font size
    const fontSizes = {
      small: '14px',
      medium: '16px',
      large: '18px',
    };
    root.style.setProperty('--font-size', fontSizes[settings.fontSize]);
    
    // Apply font family
    const fontFamilies = {
      sans: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      serif: 'Georgia, Cambria, "Times New Roman", Times, serif',
      mono: '"Courier New", Courier, monospace',
    };
    root.style.setProperty('--font-family', fontFamilies[settings.fontStyle]);
    document.body.style.fontFamily = fontFamilies[settings.fontStyle];
    
  }, [settings.theme, settings.fontSize, settings.fontStyle]);
};
