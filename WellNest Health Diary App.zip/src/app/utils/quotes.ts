// Motivational quotes for WellNest
export const motivationalQuotes = [
  "Every day is a fresh start. Embrace it with open arms.",
  "Your health is an investment, not an expense.",
  "Small steps every day lead to big changes over time.",
  "Be kind to yourself. You're doing better than you think.",
  "Wellness is a journey, not a destination.",
  "Take care of your body. It's the only place you have to live.",
  "A healthy outside starts from the inside.",
  "Progress, not perfection, is what matters.",
  "You are stronger than you realize.",
  "Nourish your mind, body, and soul daily.",
  "Self-care isn't selfish. It's essential.",
  "Believe in yourself and all that you are.",
  "One day at a time, one step at a time.",
  "Your mental health is just as important as your physical health.",
  "Rest when you need to. It's not giving up.",
  "Celebrate small victories. They add up.",
  "You're worth the time it takes to take care of yourself.",
  "Breathe deeply. You've got this.",
  "Choose yourself today and every day.",
  "Healing is not linear, and that's okay."
];

export const getRandomQuote = (): string => {
  const index = Math.floor(Math.random() * motivationalQuotes.length);
  return motivationalQuotes[index];
};

export const getDailyQuote = (): string => {
  // Use date as seed for consistent daily quote
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  const index = dayOfYear % motivationalQuotes.length;
  return motivationalQuotes[index];
};
