import React from 'react';
import { Home, Activity, BookOpen, Settings, LogOut, Heart } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentPage, onNavigate }) => {
  const { logout, user } = useApp();

  const navItems = [
    { id: 'dashboard', label: 'Home', icon: Home },
    { id: 'health', label: 'Health', icon: Activity },
    { id: 'diary', label: 'Diary', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="bg-card/95 backdrop-blur-xl border-b-2 border-border shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-2xl blur-md opacity-50"></div>
              <div className="relative bg-gradient-to-br from-primary to-accent p-2.5 rounded-2xl shadow-lg">
                <Heart className="w-7 h-7 text-white" fill="white" strokeWidth={1.5} />
              </div>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                WellNest
              </h1>
              <p className="text-xs text-muted-foreground -mt-1">Hi, {user?.name || 'Friend'}!</p>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="flex items-center space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`relative flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all duration-300 group ${
                    isActive
                      ? 'bg-gradient-to-r from-primary to-accent text-white shadow-lg'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  {isActive && (
                    <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-xl blur opacity-50"></div>
                  )}
                  <Icon className={`w-5 h-5 relative z-10 ${isActive ? 'text-white' : 'group-hover:scale-110 transition-transform'}`} />
                  <span className={`hidden md:inline relative z-10 font-medium ${isActive ? 'text-white' : ''}`}>
                    {item.label}
                  </span>
                </button>
              );
            })}

            {/* Logout */}
            <button
              onClick={logout}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl text-destructive hover:bg-destructive/10 transition-all ml-2 group"
            >
              <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="hidden md:inline font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};
