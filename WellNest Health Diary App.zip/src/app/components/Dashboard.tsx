import React from 'react';
import { Sparkles, Activity, Smile, Lock, Droplets, Moon, Heart, TrendingUp, Calendar, Award, Target } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { useApp } from '../context/AppContext';
import { getDailyQuote } from '../utils/quotes';
import { Progress } from './ui/progress';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { user, healthEntries, settings } = useApp();
  
  const today = new Date().toISOString().split('T')[0];
  const todayHealth = healthEntries[today] || {
    waterIntake: 0,
    sleepHours: 0,
    mood: 'neutral',
    notes: '',
  };

  const moodEmojis = {
    happy: '😊',
    good: '🙂',
    neutral: '😐',
    sad: '😔',
    stressed: '😰',
  };

  const moodColors = {
    happy: 'from-green-400 to-emerald-500',
    good: 'from-blue-400 to-cyan-500',
    neutral: 'from-gray-400 to-slate-500',
    sad: 'from-orange-400 to-amber-500',
    stressed: 'from-red-400 to-rose-500',
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  const waterPercentage = (todayHealth.waterIntake / 8) * 100;
  const sleepPercentage = (todayHealth.sleepHours / 8) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-secondary/20 p-4 sm:p-6 lg:p-10">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Hero Welcome Section */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-accent to-primary opacity-10 blur-3xl"></div>
          <Card className="relative border-2 border-border bg-gradient-to-br from-card via-card to-muted shadow-2xl overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-primary/20 to-transparent rounded-full blur-3xl"></div>
            <CardContent className="pt-10 pb-10 px-8 sm:px-12 relative z-10">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-3 rounded-2xl">
                      <Heart className="w-8 h-8 text-primary" />
                    </div>
                    <h1 className="text-4xl sm:text-5xl font-bold text-foreground">
                      {getGreeting()}, {user?.name || 'Friend'}!
                    </h1>
                  </div>
                  <p className="text-lg text-muted-foreground pl-14">
                    Welcome back to your wellness journey ✨
                  </p>
                </div>
                
                <div className="bg-gradient-to-br from-primary/10 to-accent/10 backdrop-blur-sm px-6 py-4 rounded-2xl border-2 border-border shadow-lg">
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-6 h-6 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Today</p>
                      <p className="text-xl font-semibold text-foreground">
                        {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Daily Quote Card */}
        {settings.showQuotes && (
          <Card className="border-2 border-border bg-gradient-to-br from-card to-muted shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
            <CardHeader className="pb-6">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-3 rounded-xl">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-2xl text-foreground">Daily Inspiration</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-8 pb-8">
              <div className="bg-gradient-to-r from-muted/50 to-transparent p-6 rounded-2xl border-l-4 border-primary">
                <p className="text-2xl text-foreground italic leading-relaxed font-light">
                  "{getDailyQuote()}"
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Health Status */}
          <Card 
            className="border-2 border-border bg-gradient-to-br from-card to-blue-50/50 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 group"
            onClick={() => onNavigate('health')}
          >
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl text-foreground">Health Status</CardTitle>
                <div className="bg-gradient-to-br from-blue-500 to-cyan-500 p-3 rounded-xl shadow-lg group-hover:shadow-xl transition-all">
                  <Activity className="w-7 h-7 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Water Progress */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <Droplets className="w-5 h-5 text-blue-600" />
                    </div>
                    <span className="font-semibold text-foreground">Water</span>
                  </div>
                  <span className="text-lg font-bold text-blue-600">
                    {todayHealth.waterIntake}/8
                  </span>
                </div>
                <div className="relative">
                  <Progress value={waterPercentage} className="h-3 bg-blue-100" />
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full opacity-20 blur"></div>
                </div>
              </div>
              
              {/* Sleep Progress */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="bg-purple-100 p-2 rounded-lg">
                      <Moon className="w-5 h-5 text-purple-600" />
                    </div>
                    <span className="font-semibold text-foreground">Sleep</span>
                  </div>
                  <span className="text-lg font-bold text-purple-600">
                    {todayHealth.sleepHours}/8h
                  </span>
                </div>
                <div className="relative">
                  <Progress value={sleepPercentage} className="h-3 bg-purple-100" />
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full opacity-20 blur"></div>
                </div>
              </div>

              <div className="pt-4 border-t-2 border-border">
                <p className="text-sm text-center text-muted-foreground group-hover:text-primary transition-colors">
                  Tap to track more →
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Mood Today */}
          <Card className="border-2 border-border bg-gradient-to-br from-card to-orange-50/50 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl text-foreground">Mood Today</CardTitle>
                <div className="bg-gradient-to-br from-orange-500 to-amber-500 p-3 rounded-xl shadow-lg">
                  <Smile className="w-7 h-7 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center justify-center py-6">
                <div className={`relative inline-block mb-4`}>
                  <div className={`absolute inset-0 bg-gradient-to-r ${moodColors[todayHealth.mood]} rounded-full blur-2xl opacity-40`}></div>
                  <div className="relative text-8xl transform hover:scale-110 transition-transform">
                    {moodEmojis[todayHealth.mood]}
                  </div>
                </div>
                <div className={`bg-gradient-to-r ${moodColors[todayHealth.mood]} bg-clip-text text-transparent`}>
                  <p className="text-2xl font-bold capitalize">{todayHealth.mood}</p>
                </div>
              </div>
              <div className="pt-4 border-t-2 border-border">
                <button 
                  onClick={() => onNavigate('health')}
                  className="w-full text-sm text-center text-muted-foreground hover:text-primary transition-colors"
                >
                  Update your mood →
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Diary Lock Status */}
          <Card className="border-2 border-border bg-gradient-to-br from-card to-purple-50/50 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl text-foreground">Diary Lock</CardTitle>
                <div className="bg-gradient-to-br from-purple-500 to-violet-500 p-3 rounded-xl shadow-lg">
                  <Lock className="w-7 h-7 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center justify-center py-6">
                <div className={`relative inline-flex items-center justify-center w-28 h-28 rounded-full mb-4 ${
                  settings.isDiaryLocked 
                    ? 'bg-gradient-to-br from-purple-100 to-violet-100' 
                    : 'bg-gradient-to-br from-green-100 to-emerald-100'
                }`}>
                  <div className={`absolute inset-0 ${
                    settings.isDiaryLocked 
                      ? 'bg-gradient-to-r from-purple-500 to-violet-500' 
                      : 'bg-gradient-to-r from-green-500 to-emerald-500'
                  } rounded-full blur-xl opacity-30`}></div>
                  <Lock className={`relative w-14 h-14 ${
                    settings.isDiaryLocked ? 'text-purple-600' : 'text-green-600'
                  }`} />
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-foreground mb-1">
                    {settings.isDiaryLocked ? 'Protected' : 'Unlocked'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {settings.isDiaryLocked ? 'Your privacy is secure' : 'Currently accessible'}
                  </p>
                </div>
              </div>
              <div className="pt-4 border-t-2 border-border">
                <button 
                  onClick={() => onNavigate('diary')}
                  className="w-full text-sm text-center text-muted-foreground hover:text-primary transition-colors"
                >
                  Open diary →
                </button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Weekly Progress Summary */}
        <Card className="border-2 border-border bg-gradient-to-br from-card to-muted shadow-xl">
          <CardHeader className="pb-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-3 rounded-xl">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-foreground">Your Wellness Journey</CardTitle>
                  <CardDescription className="text-base mt-1">Keep up the amazing work!</CardDescription>
                </div>
              </div>
              <button 
                onClick={() => onNavigate('health')}
                className="px-6 py-3 bg-gradient-to-r from-primary to-accent text-white rounded-xl hover:shadow-lg transition-all font-semibold"
              >
                View Details →
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl transform group-hover:scale-105 transition-transform"></div>
                <div className="relative text-center p-8 bg-gradient-to-br from-card to-transparent rounded-2xl border-2 border-border">
                  <div className="bg-gradient-to-br from-primary/20 to-accent/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Award className="w-9 h-9 text-primary" />
                  </div>
                  <p className="text-4xl font-bold text-foreground mb-2">{Object.keys(healthEntries).length}</p>
                  <p className="text-sm text-muted-foreground font-medium">Days Tracked</p>
                </div>
              </div>
              
              <div className="relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl transform group-hover:scale-105 transition-transform"></div>
                <div className="relative text-center p-8 bg-gradient-to-br from-card to-transparent rounded-2xl border-2 border-border">
                  <div className="bg-gradient-to-br from-blue-100 to-cyan-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Droplets className="w-9 h-9 text-blue-600" />
                  </div>
                  <p className="text-4xl font-bold text-foreground mb-2">{todayHealth.waterIntake}</p>
                  <p className="text-sm text-muted-foreground font-medium">Glasses Today</p>
                </div>
              </div>
              
              <div className="relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl transform group-hover:scale-105 transition-transform"></div>
                <div className="relative text-center p-8 bg-gradient-to-br from-card to-transparent rounded-2xl border-2 border-border">
                  <div className="bg-gradient-to-br from-purple-100 to-pink-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Moon className="w-9 h-9 text-purple-600" />
                  </div>
                  <p className="text-4xl font-bold text-foreground mb-2">{todayHealth.sleepHours}h</p>
                  <p className="text-sm text-muted-foreground font-medium">Sleep Today</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Log Water', icon: Droplets, color: 'from-blue-500 to-cyan-500', page: 'health' },
            { label: 'Track Sleep', icon: Moon, color: 'from-purple-500 to-pink-500', page: 'health' },
            { label: 'Write Diary', icon: Lock, color: 'from-violet-500 to-purple-500', page: 'diary' },
            { label: 'Update Mood', icon: Smile, color: 'from-orange-500 to-amber-500', page: 'health' },
          ].map((action, idx) => (
            <button
              key={idx}
              onClick={() => onNavigate(action.page)}
              className="group p-6 rounded-2xl border-2 border-border bg-card hover:bg-muted transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <div className={`bg-gradient-to-br ${action.color} w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform shadow-lg`}>
                <action.icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                {action.label}
              </p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
