import React, { useState } from 'react';
import { Heart, Mail, Lock, User, Eye, EyeOff, Sparkles, Shield, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { useApp } from '../context/AppContext';
import { getDailyQuote } from '../utils/quotes';

interface AuthPageProps {
  onSuccess: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onSuccess }) => {
  const { login, signup } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let success = false;
      if (isLogin) {
        success = await login(email, password);
        if (!success) {
          setError('Invalid credentials. Password must be at least 6 characters.');
        }
      } else {
        if (!name) {
          setError('Please enter your name');
          setLoading(false);
          return;
        }
        success = await signup(name, email, password);
        if (!success) {
          setError('Please check your details and try again.');
        }
      }

      if (success) {
        onSuccess();
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-accent/10 to-secondary/20 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse delay-700"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-secondary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-7xl grid lg:grid-cols-2 gap-8 lg:gap-12 items-center relative z-10">
        {/* Left side - Branding & Features */}
        <div className="hidden lg:flex flex-col justify-center space-y-8 p-8">
          {/* Logo and Title */}
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-3xl blur-xl opacity-50 animate-pulse"></div>
                <div className="relative bg-gradient-to-br from-primary to-accent p-5 rounded-3xl shadow-2xl">
                  <Heart className="w-14 h-14 text-white" fill="white" strokeWidth={1.5} />
                </div>
              </div>
              <div>
                <h1 className="text-5xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                  WellNest
                </h1>
                <p className="text-lg text-muted-foreground mt-1">Your wellness sanctuary</p>
              </div>
            </div>

            {/* Daily Quote */}
            <Card className="bg-gradient-to-br from-card via-card to-muted border-2 border-border shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="pt-8 pb-8 px-8">
                <div className="flex items-start space-x-4">
                  <Sparkles className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-xl text-foreground leading-relaxed italic font-light">
                      "{getDailyQuote()}"
                    </p>
                    <p className="text-sm text-muted-foreground mt-4">— Your daily inspiration</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Features List */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-foreground">Why WellNest?</h3>
            <div className="grid gap-5">
              {[
                { icon: TrendingUp, title: 'Track Your Progress', desc: 'Monitor health metrics with beautiful charts' },
                { icon: Shield, title: 'Secure & Private', desc: 'Your diary is protected with PIN security' },
                { icon: Heart, title: 'Holistic Wellness', desc: 'Track water, sleep, mood & more' },
              ].map((feature, idx) => (
                <div
                  key={idx}
                  className="flex items-start space-x-4 p-5 rounded-2xl bg-gradient-to-r from-muted/50 to-transparent border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg"
                >
                  <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-3 rounded-xl">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right side - Auth Form */}
        <div className="w-full">
          <Card className="shadow-2xl border-2 border-border/50 bg-card/95 backdrop-blur-xl">
            <CardHeader className="space-y-4 text-center pb-8 pt-10">
              {/* Mobile Logo */}
              <div className="lg:hidden flex items-center justify-center space-x-3 mb-4">
                <div className="bg-gradient-to-br from-primary to-accent p-3 rounded-2xl shadow-lg">
                  <Heart className="w-10 h-10 text-white" fill="white" />
                </div>
                <span className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  WellNest
                </span>
              </div>
              
              <div>
                <CardTitle className="text-3xl font-bold text-foreground mb-3">
                  {isLogin ? 'Welcome Back!' : 'Join WellNest'}
                </CardTitle>
                <CardDescription className="text-base text-muted-foreground">
                  {isLogin
                    ? 'Continue your journey to better health and wellness'
                    : 'Begin your personalized wellness journey today'}
                </CardDescription>
              </div>
            </CardHeader>

            <CardContent className="px-8 pb-10">
              <form onSubmit={handleSubmit} className="space-y-6">
                {!isLogin && (
                  <div className="space-y-3">
                    <Label htmlFor="name" className="text-base text-foreground">
                      Full Name
                    </Label>
                    <div className="relative group">
                      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <div className="relative">
                        <User className="absolute left-4 top-4 h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                        <Input
                          id="name"
                          type="text"
                          placeholder="Enter your full name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="pl-12 h-14 text-base border-2 border-border hover:border-primary/50 focus:border-primary rounded-2xl transition-all bg-input-background"
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <Label htmlFor="email" className="text-base text-foreground">
                    Email Address
                  </Label>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative">
                      <Mail className="absolute left-4 top-4 h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-12 h-14 text-base border-2 border-border hover:border-primary/50 focus:border-primary rounded-2xl transition-all bg-input-background"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="password" className="text-base text-foreground">
                    Password
                  </Label>
                  <div className="relative group">
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="relative">
                      <Lock className="absolute left-4 top-4 h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-12 pr-12 h-14 text-base border-2 border-border hover:border-primary/50 focus:border-primary rounded-2xl transition-all bg-input-background"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-4 text-muted-foreground hover:text-primary transition-colors"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="bg-destructive/10 text-destructive border-2 border-destructive/20 text-sm p-4 rounded-2xl font-medium">
                    {error}
                  </div>
                )}

                {isLogin && (
                  <div className="flex justify-end">
                    <button
                      type="button"
                      className="text-sm text-primary hover:text-primary/80 transition-colors font-medium"
                    >
                      Forgot Password?
                    </button>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white h-14 text-base rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5 font-semibold"
                >
                  {loading ? 'Please wait...' : isLogin ? 'Sign In' : 'Create Account'}
                </Button>

                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-border"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-card text-muted-foreground">
                      {isLogin ? "Don't have an account?" : 'Already have an account?'}
                    </span>
                  </div>
                </div>

                <Button
                  type="button"
                  onClick={() => {
                    setIsLogin(!isLogin);
                    setError('');
                  }}
                  variant="outline"
                  className="w-full h-12 text-base border-2 border-border hover:border-primary hover:bg-primary/5 rounded-2xl transition-all font-semibold"
                >
                  {isLogin ? 'Create New Account' : 'Sign In Instead'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Mobile Features */}
          <div className="lg:hidden mt-8 text-center text-sm text-muted-foreground">
            <p>🔒 Secure • 📊 Track Progress • 💙 Holistic Wellness</p>
          </div>
        </div>
      </div>
    </div>
  );
};
