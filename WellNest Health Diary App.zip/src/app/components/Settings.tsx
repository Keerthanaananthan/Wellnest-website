import React, { useState } from 'react';
import { Settings as SettingsIcon, Palette, Type, Quote, Lock, User, Mail, Shield, Bell } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useApp } from '../context/AppContext';
import { toast } from 'sonner';

export const Settings: React.FC = () => {
  const { user, settings, updateSettings } = useApp();
  const [newPIN, setNewPIN] = useState('');
  const [confirmPIN, setConfirmPIN] = useState('');
  const [pinError, setPinError] = useState('');

  const handleThemeChange = (theme: typeof settings.theme) => {
    updateSettings({ theme });
    toast.success('Theme updated successfully');
  };

  const handleFontSizeChange = (fontSize: typeof settings.fontSize) => {
    updateSettings({ fontSize });
    toast.success('Font size updated');
  };

  const handleFontStyleChange = (fontStyle: typeof settings.fontStyle) => {
    updateSettings({ fontStyle });
    toast.success('Font style updated');
  };

  const handleQuotesToggle = (showQuotes: boolean) => {
    updateSettings({ showQuotes });
    toast.success(showQuotes ? 'Quotes enabled' : 'Quotes disabled');
  };

  const handlePINChange = () => {
    setPinError('');
    
    if (!newPIN || !confirmPIN) {
      setPinError('Please enter PIN in both fields');
      return;
    }

    if (newPIN.length < 4) {
      setPinError('PIN must be at least 4 digits');
      return;
    }

    if (newPIN !== confirmPIN) {
      setPinError('PINs do not match');
      return;
    }

    updateSettings({ diaryPIN: newPIN });
    setNewPIN('');
    setConfirmPIN('');
    toast.success('Diary PIN updated successfully');
  };

  const themeOptions = [
    { value: 'light', label: 'Light', colors: ['#FFFFFF', '#F9FAFB', '#F3F4F6'], desc: 'Clean and minimal' },
    { value: 'paleBlue', label: 'Pale Blue', colors: ['#F0F9FF', '#E0F2FE', '#BAE6FD'], desc: 'Calm and soothing' },
    { value: 'pastel', label: 'Soft Pastel', colors: ['#FFF5F7', '#FEE2E2', '#FECACA'], desc: 'Warm and gentle' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F9FAFB] via-[#E8F4F8] to-[#D6EFF5] p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl text-[#2C5F7C] mb-2">Settings</h1>
          <p className="text-[#5EB3CD]">Customize your WellNest experience</p>
        </div>

        {/* Profile Information */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#D6EFF5] p-2 rounded-xl">
                <User className="w-5 h-5 text-[#5EB3CD]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Profile Information</CardTitle>
            </div>
            <CardDescription>Your account details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[#2C5F7C]">Name</Label>
                <div className="flex items-center space-x-2 p-3 bg-[#E8F4F8] rounded-xl">
                  <User className="w-4 h-4 text-[#5EB3CD]" />
                  <span className="text-[#2C5F7C]">{user?.name || 'User'}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-[#2C5F7C]">Email</Label>
                <div className="flex items-center space-x-2 p-3 bg-[#E8F4F8] rounded-xl">
                  <Mail className="w-4 h-4 text-[#5EB3CD]" />
                  <span className="text-[#2C5F7C]">{user?.email || 'user@email.com'}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Theme Customization */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#FFE8D6] p-2 rounded-xl">
                <Palette className="w-5 h-5 text-[#F4A261]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Theme Customization</CardTitle>
            </div>
            <CardDescription>Choose your preferred color scheme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {themeOptions.map((theme) => (
                <button
                  key={theme.value}
                  onClick={() => handleThemeChange(theme.value as typeof settings.theme)}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    settings.theme === theme.value
                      ? 'border-[#5EB3CD] shadow-md scale-105'
                      : 'border-[#D6EFF5] hover:border-[#5EB3CD]'
                  }`}
                >
                  <div className="flex space-x-2 mb-3">
                    {theme.colors.map((color, idx) => (
                      <div
                        key={idx}
                        className="w-8 h-8 rounded-lg shadow-sm"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-[#2C5F7C]">{theme.label}</p>
                  <p className="text-xs text-[#5EB3CD]">{theme.desc}</p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Typography Settings */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#E9D5FF] p-2 rounded-xl">
                <Type className="w-5 h-5 text-[#9333EA]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Typography</CardTitle>
            </div>
            <CardDescription>Adjust text appearance for better readability</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-[#2C5F7C]">Font Size</Label>
              <Select value={settings.fontSize} onValueChange={handleFontSizeChange}>
                <SelectTrigger className="border-[#B8E1ED] rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small</SelectItem>
                  <SelectItem value="medium">Medium (Recommended)</SelectItem>
                  <SelectItem value="large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-[#2C5F7C]">Font Style</Label>
              <Select value={settings.fontStyle} onValueChange={handleFontStyleChange}>
                <SelectTrigger className="border-[#B8E1ED] rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sans">Sans Serif (Default)</SelectItem>
                  <SelectItem value="serif">Serif</SelectItem>
                  <SelectItem value="mono">Monospace</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Motivational Quotes */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#FFF8F0]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#FFF0E0] p-2 rounded-xl">
                <Quote className="w-5 h-5 text-[#F4A261]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Motivational Quotes</CardTitle>
            </div>
            <CardDescription>Display daily inspirational messages</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#2C5F7C] mb-1">Show Daily Quotes</p>
                <p className="text-sm text-[#5EB3CD]">
                  Display motivational quotes on your dashboard
                </p>
              </div>
              <Switch
                checked={settings.showQuotes}
                onCheckedChange={handleQuotesToggle}
              />
            </div>
          </CardContent>
        </Card>

        {/* Diary Security */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F5F0FF]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#E9D5FF] p-2 rounded-xl">
                <Shield className="w-5 h-5 text-[#9333EA]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Diary Security</CardTitle>
            </div>
            <CardDescription>Change your diary PIN for enhanced privacy</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-[#F3E8FF] border border-[#E9D5FF] p-4 rounded-xl">
              <div className="flex items-start space-x-2">
                <Lock className="w-5 h-5 text-[#9333EA] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-[#2C5F7C] mb-1">Current PIN Protection</p>
                  <p className="text-xs text-[#9333EA]">
                    Your diary is protected with a {settings.diaryPIN.length}-digit PIN
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[#2C5F7C]">New PIN</Label>
                <Input
                  type="password"
                  placeholder="Enter new PIN"
                  value={newPIN}
                  onChange={(e) => setNewPIN(e.target.value)}
                  className="border-[#E9D5FF] focus:border-[#9333EA] rounded-xl"
                  maxLength={6}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[#2C5F7C]">Confirm PIN</Label>
                <Input
                  type="password"
                  placeholder="Confirm new PIN"
                  value={confirmPIN}
                  onChange={(e) => setConfirmPIN(e.target.value)}
                  className="border-[#E9D5FF] focus:border-[#9333EA] rounded-xl"
                  maxLength={6}
                />
              </div>
            </div>

            {pinError && (
              <p className="text-sm text-red-600">{pinError}</p>
            )}

            <Button
              onClick={handlePINChange}
              className="w-full sm:w-auto bg-[#9333EA] hover:bg-[#7E22CE] text-white rounded-xl"
            >
              Update PIN
            </Button>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#D6EFF5] p-2 rounded-xl">
                <Bell className="w-5 h-5 text-[#5EB3CD]" />
              </div>
              <CardTitle className="text-[#2C5F7C]">Reminders</CardTitle>
            </div>
            <CardDescription>Gentle reminders to support your wellness routine</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-[#D6EFF5]">
              <div>
                <p className="text-[#2C5F7C]">Water Intake Reminder</p>
                <p className="text-sm text-[#5EB3CD]">Remind me to drink water</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between py-3 border-b border-[#D6EFF5]">
              <div>
                <p className="text-[#2C5F7C]">Diary Reminder</p>
                <p className="text-sm text-[#5EB3CD]">Daily journaling reminder</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between py-3">
              <div>
                <p className="text-[#2C5F7C]">Sleep Reminder</p>
                <p className="text-sm text-[#5EB3CD]">Remind me to sleep on time</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardContent className="py-6 text-center">
            <p className="text-sm text-[#2C5F7C]/70">
              WellNest v1.0 - Your Personal Wellness Companion
            </p>
            <p className="text-xs text-[#5EB3CD] mt-2">
              Built with care for your health and privacy
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};