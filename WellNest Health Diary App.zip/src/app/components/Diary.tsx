import React, { useState } from 'react';
import { Lock, Unlock, Plus, Edit, Trash2, Archive, Eye, EyeOff, Calendar, Search, BookOpen, Shield } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { useApp } from '../context/AppContext';
import { DiaryEntry } from '../types';

export const Diary: React.FC = () => {
  const {
    diaryEntries,
    settings,
    isDiaryUnlocked,
    unlockDiary,
    lockDiary,
    addDiaryEntry,
    updateDiaryEntry,
    deleteDiaryEntry,
  } = useApp();

  const [pinInput, setPinInput] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [pinError, setPinError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  
  // Entry editor state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null);
  const [entryTitle, setEntryTitle] = useState('');
  const [entryContent, setEntryContent] = useState('');

  const handleUnlock = () => {
    if (unlockDiary(pinInput)) {
      setPinInput('');
      setPinError('');
    } else {
      setPinError('Incorrect PIN. Default PIN is 1234');
    }
  };

  const handleCreateEntry = () => {
    setEditingEntry(null);
    setEntryTitle('');
    setEntryContent('');
    setIsEditorOpen(true);
  };

  const handleEditEntry = (entry: DiaryEntry) => {
    setEditingEntry(entry);
    setEntryTitle(entry.title);
    setEntryContent(entry.content);
    setIsEditorOpen(true);
  };

  const handleSaveEntry = () => {
    if (!entryTitle.trim() || !entryContent.trim()) return;

    if (editingEntry) {
      updateDiaryEntry(editingEntry.id, {
        title: entryTitle,
        content: entryContent,
      });
    } else {
      addDiaryEntry({
        date: new Date().toISOString().split('T')[0],
        title: entryTitle,
        content: entryContent,
        isArchived: false,
      });
    }

    setIsEditorOpen(false);
    setEntryTitle('');
    setEntryContent('');
    setEditingEntry(null);
  };

  const handleArchiveEntry = (id: string, isArchived: boolean) => {
    updateDiaryEntry(id, { isArchived: !isArchived });
  };

  const handleDeleteEntry = (id: string) => {
    if (window.confirm('Are you sure you want to delete this entry? This cannot be undone.')) {
      deleteDiaryEntry(id);
    }
  };

  // Filter entries
  const filteredEntries = diaryEntries.filter((entry) => {
    const matchesSearch = entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         entry.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesArchive = showArchived ? entry.isArchived : !entry.isArchived;
    return matchesSearch && matchesArchive;
  });

  if (!isDiaryUnlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#F9FAFB] via-[#E8F4F8] to-[#D6EFF5] flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-none shadow-2xl bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="bg-gradient-to-br from-[#9333EA] to-[#7E22CE] p-4 rounded-2xl shadow-lg">
                <Shield className="w-12 h-12 text-white" />
              </div>
            </div>
            <div>
              <CardTitle className="text-2xl text-[#2C5F7C] mb-2">Secure Diary</CardTitle>
              <CardDescription>
                Your personal thoughts are protected. Enter your PIN to continue.
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm text-[#2C5F7C]">Enter PIN</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-[#9333EA]" />
                <Input
                  type={showPin ? 'text' : 'password'}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleUnlock()}
                  placeholder="Enter your PIN"
                  className="pl-10 pr-10 border-[#E9D5FF] focus:border-[#9333EA] rounded-xl"
                  maxLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-3 text-[#9333EA]"
                >
                  {showPin ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              {pinError && (
                <p className="text-sm text-red-600">{pinError}</p>
              )}
            </div>

            <Button
              onClick={handleUnlock}
              className="w-full bg-gradient-to-r from-[#9333EA] to-[#7E22CE] hover:from-[#7E22CE] hover:to-[#6B21A8] text-white rounded-xl h-11 shadow-lg"
            >
              <Unlock className="w-5 h-5 mr-2" />
              Unlock Diary
            </Button>

            <div className="pt-4 border-t border-[#E9D5FF]">
              <p className="text-xs text-center text-[#2C5F7C]/70">
                Your diary is protected with PIN authentication. You can change your PIN in Settings.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F9FAFB] via-[#E8F4F8] to-[#D6EFF5] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl text-[#2C5F7C] mb-2">Personal Diary</h1>
            <p className="text-[#5EB3CD]">Your private space for thoughts and reflections</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={lockDiary}
              variant="outline"
              className="border-[#E9D5FF] text-[#9333EA] hover:bg-[#F3E8FF] rounded-xl"
            >
              <Lock className="w-4 h-4 mr-2" />
              Lock Diary
            </Button>
            <Button
              onClick={handleCreateEntry}
              className="bg-gradient-to-r from-[#5EB3CD] to-[#7DC8DD] hover:from-[#4A9FB8] hover:to-[#6BB7CC] text-white rounded-xl shadow-lg"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Entry
            </Button>
          </div>
        </div>

        {/* Search and Filter */}
        <Card className="border-none shadow-md bg-white">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-[#5EB3CD]" />
                <Input
                  type="text"
                  placeholder="Search entries..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 border-[#B8E1ED] rounded-xl"
                />
              </div>
              <Button
                onClick={() => setShowArchived(!showArchived)}
                variant="outline"
                className="border-[#B8E1ED] text-[#5EB3CD] hover:bg-[#E8F4F8] rounded-xl"
              >
                <Archive className="w-4 h-4 mr-2" />
                {showArchived ? 'Show Active' : 'Show Archived'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Entries List */}
        {filteredEntries.length === 0 ? (
          <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
            <CardContent className="py-16 text-center">
              <BookOpen className="w-16 h-16 text-[#5EB3CD] mx-auto mb-4 opacity-50" />
              <h3 className="text-xl text-[#2C5F7C] mb-2">No entries yet</h3>
              <p className="text-[#5EB3CD] mb-6">
                {showArchived
                  ? "You don't have any archived entries"
                  : 'Start your journaling journey by creating your first entry'}
              </p>
              {!showArchived && (
                <Button
                  onClick={handleCreateEntry}
                  className="bg-[#5EB3CD] hover:bg-[#4A9FB8] text-white rounded-xl"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Entry
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEntries.map((entry) => (
              <Card
                key={entry.id}
                className="border-none shadow-lg hover:shadow-xl transition-all bg-gradient-to-br from-white to-[#F0F9FB] group"
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-[#2C5F7C] mb-2 line-clamp-1">
                        {entry.title}
                      </CardTitle>
                      <div className="flex items-center space-x-2 text-sm text-[#5EB3CD]">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {new Date(entry.date).toLocaleDateString('en-US', {
                            month: 'long',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </span>
                      </div>
                    </div>
                    {entry.isArchived && (
                      <div className="bg-[#FFF0E0] px-2 py-1 rounded-lg">
                        <span className="text-xs text-[#F4A261]">Archived</span>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-[#2C5F7C]/80 line-clamp-3">{entry.content}</p>
                  
                  <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      onClick={() => handleEditEntry(entry)}
                      size="sm"
                      variant="outline"
                      className="flex-1 border-[#B8E1ED] text-[#5EB3CD] hover:bg-[#E8F4F8] rounded-lg"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={() => handleArchiveEntry(entry.id, entry.isArchived)}
                      size="sm"
                      variant="outline"
                      className="border-[#FFE8D6] text-[#F4A261] hover:bg-[#FFF8F0] rounded-lg"
                    >
                      <Archive className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={() => handleDeleteEntry(entry.id)}
                      size="sm"
                      variant="outline"
                      className="border-red-200 text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Entry Editor Dialog */}
        <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-[#2C5F7C]">
                {editingEntry ? 'Edit Entry' : 'New Diary Entry'}
              </DialogTitle>
              <DialogDescription>
                Write your thoughts, feelings, and reflections
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm text-[#2C5F7C]">Title</label>
                <Input
                  type="text"
                  placeholder="Give your entry a title..."
                  value={entryTitle}
                  onChange={(e) => setEntryTitle(e.target.value)}
                  className="border-[#B8E1ED] focus:border-[#5EB3CD] rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#2C5F7C]">Content</label>
                <Textarea
                  placeholder="Write your thoughts here..."
                  value={entryContent}
                  onChange={(e) => setEntryContent(e.target.value)}
                  className="min-h-[300px] border-[#B8E1ED] focus:border-[#5EB3CD] rounded-xl"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                onClick={() => setIsEditorOpen(false)}
                variant="outline"
                className="border-[#B8E1ED] text-[#5EB3CD] hover:bg-[#E8F4F8] rounded-xl"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEntry}
                disabled={!entryTitle.trim() || !entryContent.trim()}
                className="bg-[#5EB3CD] hover:bg-[#4A9FB8] text-white rounded-xl"
              >
                {editingEntry ? 'Update Entry' : 'Save Entry'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};
