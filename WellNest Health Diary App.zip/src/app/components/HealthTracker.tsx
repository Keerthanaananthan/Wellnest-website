import React, { useState } from 'react';
import { Droplets, Moon, Smile, FileText, Plus, Minus, Calendar, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { useApp } from '../context/AppContext';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

export const HealthTracker: React.FC = () => {
  const { healthEntries, updateHealthEntry } = useApp();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  
  const currentEntry = healthEntries[selectedDate] || {
    date: selectedDate,
    waterIntake: 0,
    sleepHours: 0,
    mood: 'neutral' as const,
    notes: '',
  };

  const moodOptions = [
    { value: 'happy', emoji: '😊', label: 'Happy', color: '#10B981' },
    { value: 'good', emoji: '🙂', label: 'Good', color: '#3B82F6' },
    { value: 'neutral', emoji: '😐', label: 'Neutral', color: '#6B7280' },
    { value: 'sad', emoji: '😔', label: 'Sad', color: '#F59E0B' },
    { value: 'stressed', emoji: '😰', label: 'Stressed', color: '#EF4444' },
  ];

  const updateWater = (change: number) => {
    const newValue = Math.max(0, Math.min(12, currentEntry.waterIntake + change));
    updateHealthEntry(selectedDate, { ...currentEntry, waterIntake: newValue });
  };

  const updateSleep = (change: number) => {
    const newValue = Math.max(0, Math.min(12, currentEntry.sleepHours + change));
    updateHealthEntry(selectedDate, { ...currentEntry, sleepHours: newValue });
  };

  const updateMood = (mood: typeof currentEntry.mood) => {
    updateHealthEntry(selectedDate, { ...currentEntry, mood });
  };

  const updateNotes = (notes: string) => {
    updateHealthEntry(selectedDate, { ...currentEntry, notes });
  };

  // Prepare chart data for last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const dateStr = date.toISOString().split('T')[0];
    const entry = healthEntries[dateStr];
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      water: entry?.waterIntake || 0,
      sleep: entry?.sleepHours || 0,
    };
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F9FAFB] via-[#E8F4F8] to-[#D6EFF5] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl text-[#2C5F7C] mb-2">Health Tracker</h1>
            <p className="text-[#5EB3CD]">Monitor your daily wellness activities</p>
          </div>
          <div className="flex items-center space-x-2 bg-white rounded-xl p-2 shadow-md">
            <Calendar className="w-5 h-5 text-[#5EB3CD]" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border-none bg-transparent text-[#2C5F7C] focus:outline-none"
            />
          </div>
        </div>

        {/* Tracking Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Water Intake */}
          <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#E8F4F8]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="bg-[#D6EFF5] p-2 rounded-xl">
                    <Droplets className="w-6 h-6 text-[#5EB3CD]" />
                  </div>
                  <div>
                    <CardTitle className="text-[#2C5F7C]">Water Intake</CardTitle>
                    <CardDescription>Daily goal: 8 glasses</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-center space-x-4">
                <Button
                  onClick={() => updateWater(-1)}
                  disabled={currentEntry.waterIntake === 0}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-xl border-[#B8E1ED] text-[#5EB3CD] hover:bg-[#D6EFF5]"
                >
                  <Minus className="w-5 h-5" />
                </Button>
                <div className="text-center min-w-[120px]">
                  <div className="text-5xl text-[#2C5F7C] mb-1">{currentEntry.waterIntake}</div>
                  <div className="text-sm text-[#5EB3CD]">glasses</div>
                </div>
                <Button
                  onClick={() => updateWater(1)}
                  disabled={currentEntry.waterIntake >= 12}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-xl border-[#B8E1ED] text-[#5EB3CD] hover:bg-[#D6EFF5]"
                >
                  <Plus className="w-5 h-5" />
                </Button>
              </div>
              <div className="space-y-2">
                <Progress value={(currentEntry.waterIntake / 8) * 100} className="h-3" />
                <p className="text-sm text-center text-[#5EB3CD]">
                  {currentEntry.waterIntake >= 8 ? '🎉 Goal achieved!' : `${8 - currentEntry.waterIntake} more to go`}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Sleep Hours */}
          <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F0FB]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="bg-[#E9D5FF] p-2 rounded-xl">
                    <Moon className="w-6 h-6 text-[#9333EA]" />
                  </div>
                  <div>
                    <CardTitle className="text-[#2C5F7C]">Sleep Hours</CardTitle>
                    <CardDescription>Daily goal: 8 hours</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-center space-x-4">
                <Button
                  onClick={() => updateSleep(-0.5)}
                  disabled={currentEntry.sleepHours === 0}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-xl border-[#E9D5FF] text-[#9333EA] hover:bg-[#F3E8FF]"
                >
                  <Minus className="w-5 h-5" />
                </Button>
                <div className="text-center min-w-[120px]">
                  <div className="text-5xl text-[#2C5F7C] mb-1">{currentEntry.sleepHours}</div>
                  <div className="text-sm text-[#9333EA]">hours</div>
                </div>
                <Button
                  onClick={() => updateSleep(0.5)}
                  disabled={currentEntry.sleepHours >= 12}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 rounded-xl border-[#E9D5FF] text-[#9333EA] hover:bg-[#F3E8FF]"
                >
                  <Plus className="w-5 h-5" />
                </Button>
              </div>
              <div className="space-y-2">
                <Progress value={(currentEntry.sleepHours / 8) * 100} className="h-3" />
                <p className="text-sm text-center text-[#9333EA]">
                  {currentEntry.sleepHours >= 8 ? '🌟 Well rested!' : `${(8 - currentEntry.sleepHours).toFixed(1)} more hours recommended`}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Mood Tracking */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#FFF8F0]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#FFF0E0] p-2 rounded-xl">
                <Smile className="w-6 h-6 text-[#F4A261]" />
              </div>
              <div>
                <CardTitle className="text-[#2C5F7C]">Mood Tracking</CardTitle>
                <CardDescription>How are you feeling today?</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {moodOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => updateMood(option.value as typeof currentEntry.mood)}
                  className={`p-4 rounded-xl border-2 transition-all text-center ${
                    currentEntry.mood === option.value
                      ? 'border-[#F4A261] bg-[#FFF0E0] shadow-md scale-105'
                      : 'border-[#FFE8D6] bg-white hover:border-[#F4A261] hover:bg-[#FFF8F0]'
                  }`}
                >
                  <div className="text-4xl mb-2">{option.emoji}</div>
                  <div className="text-sm text-[#2C5F7C]">{option.label}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Health Notes */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="bg-[#D6EFF5] p-2 rounded-xl">
                <FileText className="w-6 h-6 text-[#5EB3CD]" />
              </div>
              <div>
                <CardTitle className="text-[#2C5F7C]">Health Notes</CardTitle>
                <CardDescription>Add any additional notes about your day</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              value={currentEntry.notes}
              onChange={(e) => updateNotes(e.target.value)}
              placeholder="How did you feel today? Any symptoms or observations?"
              className="min-h-[120px] border-[#B8E1ED] focus:border-[#5EB3CD] rounded-xl"
            />
          </CardContent>
        </Card>

        {/* Progress Charts */}
        <Card className="border-none shadow-lg bg-gradient-to-br from-white to-[#F0F9FB]">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-[#5EB3CD]" />
              <CardTitle className="text-[#2C5F7C]">7-Day Progress</CardTitle>
            </div>
            <CardDescription>Your wellness trends over the last week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm text-[#2C5F7C] mb-4 text-center">Water Intake</h4>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={last7Days}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D6EFF5" />
                    <XAxis dataKey="date" tick={{ fill: '#5EB3CD', fontSize: 12 }} />
                    <YAxis tick={{ fill: '#5EB3CD', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'white',
                        border: '1px solid #D6EFF5',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="water" fill="#5EB3CD" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div>
                <h4 className="text-sm text-[#2C5F7C] mb-4 text-center">Sleep Hours</h4>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={last7Days}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E9D5FF" />
                    <XAxis dataKey="date" tick={{ fill: '#9333EA', fontSize: 12 }} />
                    <YAxis tick={{ fill: '#9333EA', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'white',
                        border: '1px solid #E9D5FF',
                        borderRadius: '8px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="sleep"
                      stroke="#9333EA"
                      strokeWidth={3}
                      dot={{ fill: '#9333EA', r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
