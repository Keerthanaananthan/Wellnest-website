import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, HealthEntry, DiaryEntry, AppSettings, AppData } from '../types';

interface AppContextType {
  user: User | null;
  healthEntries: Record<string, HealthEntry>;
  diaryEntries: DiaryEntry[];
  settings: AppSettings;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateHealthEntry: (date: string, entry: Partial<HealthEntry>) => void;
  addDiaryEntry: (entry: Omit<DiaryEntry, 'id' | 'createdAt'>) => void;
  updateDiaryEntry: (id: string, updates: Partial<DiaryEntry>) => void;
  deleteDiaryEntry: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  isDiaryUnlocked: boolean;
  unlockDiary: (pin: string) => boolean;
  lockDiary: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'wellnest_data';
const SESSION_KEY = 'wellnest_session';

const defaultSettings: AppSettings = {
  theme: 'paleBlue',
  fontSize: 'medium',
  fontStyle: 'sans',
  showQuotes: true,
  diaryPIN: '1234',
  isDiaryLocked: true,
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [healthEntries, setHealthEntries] = useState<Record<string, HealthEntry>>({});
  const [diaryEntries, setDiaryEntries] = useState<DiaryEntry[]>([]);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [isDiaryUnlocked, setIsDiaryUnlocked] = useState(false);

  // Load data from localStorage
  useEffect(() => {
    const storedData = localStorage.getItem(STORAGE_KEY);
    const sessionData = sessionStorage.getItem(SESSION_KEY);
    
    if (storedData) {
      try {
        const data: AppData = JSON.parse(storedData);
        setHealthEntries(data.healthEntries || {});
        setDiaryEntries(data.diaryEntries || []);
        setSettings({ ...defaultSettings, ...data.settings });
      } catch (error) {
        console.error('Error loading data:', error);
      }
    }

    if (sessionData) {
      try {
        const userData: User = JSON.parse(sessionData);
        setUser(userData);
      } catch (error) {
        console.error('Error loading session:', error);
      }
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    if (user) {
      const data: AppData = {
        user,
        healthEntries,
        diaryEntries,
        settings,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, [user, healthEntries, diaryEntries, settings]);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock authentication
    // In a real app, this would call an API
    if (email && password.length >= 6) {
      const userData: User = {
        id: '1',
        name: email.split('@')[0],
        email,
        createdAt: new Date().toISOString(),
      };
      setUser(userData);
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    // Mock registration
    if (name && email && password.length >= 6) {
      const userData: User = {
        id: Date.now().toString(),
        name,
        email,
        createdAt: new Date().toISOString(),
      };
      setUser(userData);
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem(SESSION_KEY);
    setIsDiaryUnlocked(false);
  };

  const updateHealthEntry = (date: string, entry: Partial<HealthEntry>) => {
    setHealthEntries(prev => ({
      ...prev,
      [date]: { ...prev[date], date, ...entry } as HealthEntry,
    }));
  };

  const addDiaryEntry = (entry: Omit<DiaryEntry, 'id' | 'createdAt'>) => {
    const newEntry: DiaryEntry = {
      ...entry,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setDiaryEntries(prev => [newEntry, ...prev]);
  };

  const updateDiaryEntry = (id: string, updates: Partial<DiaryEntry>) => {
    setDiaryEntries(prev =>
      prev.map(entry => (entry.id === id ? { ...entry, ...updates } : entry))
    );
  };

  const deleteDiaryEntry = (id: string) => {
    setDiaryEntries(prev => prev.filter(entry => entry.id !== id));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const unlockDiary = (pin: string): boolean => {
    if (pin === settings.diaryPIN) {
      setIsDiaryUnlocked(true);
      return true;
    }
    return false;
  };

  const lockDiary = () => {
    setIsDiaryUnlocked(false);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        healthEntries,
        diaryEntries,
        settings,
        login,
        signup,
        logout,
        updateHealthEntry,
        addDiaryEntry,
        updateDiaryEntry,
        deleteDiaryEntry,
        updateSettings,
        isDiaryUnlocked,
        unlockDiary,
        lockDiary,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
