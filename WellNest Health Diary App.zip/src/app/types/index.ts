// Types for WellNest application

export interface User {
  id: string;
  name: string;
  email: string;
  createdAt: string;
}

export interface HealthEntry {
  date: string;
  waterIntake: number; // in glasses
  sleepHours: number;
  mood: 'happy' | 'good' | 'neutral' | 'sad' | 'stressed';
  notes: string;
}

export interface DiaryEntry {
  id: string;
  date: string;
  title: string;
  content: string;
  createdAt: string;
  isArchived: boolean;
}

export interface AppSettings {
  theme: 'light' | 'paleBlue' | 'pastel';
  fontSize: 'small' | 'medium' | 'large';
  fontStyle: 'sans' | 'serif' | 'mono';
  showQuotes: boolean;
  diaryPIN: string;
  isDiaryLocked: boolean;
}

export interface AppData {
  user: User | null;
  healthEntries: Record<string, HealthEntry>;
  diaryEntries: DiaryEntry[];
  settings: AppSettings;
}
