
  # WellNest Health Diary App

  This is a code bundle for WellNest Health Diary App. The original project is available at https://www.figma.com/design/tDbeNDowoepjbZ0FQAmF2b/WellNest-Health-Diary-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  